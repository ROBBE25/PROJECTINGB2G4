/* USER CODE BEGIN Header */
/**
 ******************************************************************************
 * @file           : main.c
 * @brief          : Main program body
 ******************************************************************************
 * @attention
 *
 * <h2><center>&copy; Copyright (c) 2024 STMicroelectronics.
 * All rights reserved.</center></h2>
 *
 * This software component is licensed by ST under BSD 3-Clause license,
 * the "License"; You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at:
 *                        opensource.org/licenses/BSD-3-Clause
 *
 ******************************************************************************
 */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include<stdio.h>

#include<string.h>


/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */
/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
ADC_HandleTypeDef hadc1;

I2C_HandleTypeDef hi2c1;

SPI_HandleTypeDef hspi1;

UART_HandleTypeDef huart1;
UART_HandleTypeDef huart2;

/* USER CODE BEGIN PV */
double pressure = 0;
float elevation = 0;

const uint8_t READ_PRESSURE = 0b10000100; // 0x04 + 0b10000000
const uint8_t READ_TEMP = 0b10000111; // 0x07 + 0b10000000
const uint8_t READ_PRESSURE_AND_TEMP = 0b10000100; // 0x04 + 0b10000000

const uint8_t READ_ENABLES = 0b10011011; // 0x1B + 0b10000000
const uint8_t READ_OSR = 0b10011100; // 0x1C + 0b10000000
const uint8_t READ_STATUS = 0b10000011; // 0x03 + 0b10000000
const uint8_t READ_IF_CONF = 0b10011010; // 0x1A + 0b10000000

const uint8_t WRITE_ENABLES[2] = {0x1B + 0b00000000, 0b00010011}; // {0x1B + 0b00000000, 0b00010011} pressure and temperature Enable
// Forced mode: [5:4]==01 and pressure enabled: bit[0] == 1

const uint8_t WRITE_OSR[2] = {0b00011100, 0b00000000}; // {0x1C + 0b00000000, 0b00000000} osr_t == 000  osr_p == 000
// {0x1C + 0b00000000, 0b00011000} osr_t == 011  osr_p == 000



// parameters for conversion of temperature sensor values to real temperature value
uint16_t NVM_PAR_T1;
uint16_t NVM_PAR_T2;
int8_t NVM_PAR_T3;
double t_lin;


// parameters for conversion of pressure sensor values to real pressure value
int16_t NVM_PAR_P1;
int16_t NVM_PAR_P2;
int8_t NVM_PAR_P3;
int8_t NVM_PAR_P4;
uint16_t NVM_PAR_P5;
uint16_t NVM_PAR_P6;
int8_t NVM_PAR_P7;
int8_t NVM_PAR_P8;
int16_t NVM_PAR_P9;
int8_t NVM_PAR_P10;
int8_t NVM_PAR_P11;

uint8_t read_buffer[256];

//Adress of the sensors that use I2C
static const uint8_t MICSVZ89_ADDR = 0x70 << 1; //Leave room for Read/Write bit
static const uint8_t HIH7000_ADDR = 0x27 << 1;  //Leave room for Read/Write bit

// Light sensor variables intialisation
uint16_t lux =0;
float lux_f = 0;
unsigned int lux_d = 0;

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_I2C1_Init(void);
static void MX_ADC1_Init(void);
static void MX_SPI1_Init(void);
static void MX_USART1_UART_Init(void);
/* USER CODE BEGIN PFP */
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
void get_NVM_parameters(void){
uint8_t READ_NVM_PAR_addr = 0x31 + 0b10000000;  // base address of NVM_PAR_T1 + read bit

HAL_Delay(50);
HAL_GPIO_WritePin(GPIOA, GPIO_PIN_15, GPIO_PIN_RESET);
HAL_SPI_Transmit(&hspi1, (uint8_t *)&READ_NVM_PAR_addr, 1, 1000);
HAL_SPI_Receive(&hspi1, (uint8_t *) read_buffer, 22, 1000);
HAL_GPIO_WritePin(GPIOA, GPIO_PIN_15, GPIO_PIN_SET);

//temperature
NVM_PAR_T1 = (uint16_t)(read_buffer[2]<<8) | (uint16_t)read_buffer[1];
NVM_PAR_T2 = (uint16_t)(read_buffer[4]<<8) | (uint16_t)read_buffer[3];
NVM_PAR_T3 = (int8_t) read_buffer[5];

//pressure
NVM_PAR_P1 = (int16_t)(read_buffer[7]<<8) | (int16_t)read_buffer[6];
NVM_PAR_P2 = (int16_t)(read_buffer[9]<<8) | (int16_t)read_buffer[8];
NVM_PAR_P3 = (int8_t)read_buffer[10];
NVM_PAR_P4 = (int8_t)read_buffer[11];
NVM_PAR_P5 = (uint16_t)(read_buffer[13]<<8) | (uint16_t)read_buffer[12];
NVM_PAR_P6 = (uint16_t)(read_buffer[15]<<8) | (uint16_t)read_buffer[14];
NVM_PAR_P7 = (int8_t)read_buffer[16];
NVM_PAR_P8 = (int8_t)read_buffer[17];
NVM_PAR_P9 = (int16_t)(read_buffer[19]<<8) | (int16_t)read_buffer[18];
NVM_PAR_P10 = (int8_t)read_buffer[20];
NVM_PAR_P11 = (int8_t)read_buffer[21];


}


float compensate_temperature (uint32_t sensor_temperature){
double partial_data1;
double partial_data2;

double temp_var;

  /* 2^(-8) */
  temp_var = 0.00390625f;
double PAR_T1 = (double)NVM_PAR_T1 / temp_var;

/* 2^30 */
temp_var = 1073741824.0f;
double PAR_T2 = (double)NVM_PAR_T2 / temp_var;

/* 2^48 */
temp_var = 281474976710656.0f;
double PAR_T3 = (double)NVM_PAR_T3 / temp_var;

partial_data1 = ((double)sensor_temperature - PAR_T1);
partial_data2 = (partial_data1 * PAR_T2);

t_lin = partial_data2 + (partial_data1 * partial_data1) * PAR_T3;
return (float)t_lin;

}

float compensate_pressure(uint32_t sensor_pressure){
double partial_data1;
double partial_data2;
double partial_data3;
double partial_data4;

double partial_out1;
double partial_out2;

double temp_var;
double comp_press;
double pressure = (double)sensor_pressure;

/* 1 / 2^20 */
  temp_var = 1048576.0f;
double PAR_P1 = (double)(NVM_PAR_P1 - 16384) / temp_var;

/* 1 / 2^29 */
  temp_var = 536870912.0f;
  double PAR_P2 = (double)(NVM_PAR_P2 - 16384) / temp_var;

  /* 1 / 2^32 */
  temp_var = 4294967296.0f;
  double PAR_P3 = (double)NVM_PAR_P3 / temp_var;

  /* 1 / 2^37 */
  temp_var = 137438953472.0f;
  double PAR_P4 = (double)NVM_PAR_P4 / temp_var;

  /* 1 / 2^(-3) */
  temp_var = 0.125f;
  double PAR_P5 = (double)NVM_PAR_P5 / temp_var;

  /* 1 / 2^6 */
  temp_var = 64.0f;
  double PAR_P6 = (double)NVM_PAR_P6 / temp_var;

  /* 1 / 2^8 */
  temp_var = 256.0f;
  double PAR_P7 = (double)NVM_PAR_P7 / temp_var;

  /* 1 / 2^15 */
  temp_var = 32768.0f;
  double PAR_P8 = (double)NVM_PAR_P8 / temp_var;

  /* 1 / 2^48 */
  temp_var = 281474976710656.0f;
  double PAR_P9 = (double)NVM_PAR_P9 / temp_var;

  /* 1 / 2^48 */
  temp_var = 281474976710656.0f;
  double PAR_P10 = (double)NVM_PAR_P10 / temp_var;

  /* 1 / 2^65 */
  temp_var = 36893488147419103232.0f;
  double PAR_P11 = (double)NVM_PAR_P11 / temp_var;

  partial_data1 = PAR_P6 * t_lin;
  partial_data2 = PAR_P7 * t_lin * t_lin;
  partial_data3 = PAR_P8  * t_lin * t_lin * t_lin;
  partial_out1 = PAR_P5 + partial_data1 + partial_data2 + partial_data3;

  partial_data1 = PAR_P2 * t_lin;
  partial_data2 = PAR_P3 * t_lin * t_lin;
  partial_data3 = PAR_P4  * t_lin * t_lin * t_lin;
  partial_out2 = pressure * (PAR_P1 + partial_data1 + partial_data2 + partial_data3);

  partial_data1 = pressure * pressure;
  partial_data2 = PAR_P9 + PAR_P10 * t_lin;
  partial_data3 = partial_data1 * partial_data2;
  partial_data4 = partial_data3 + pressure * pressure * pressure * PAR_P11;

  comp_press = partial_out1 + partial_out2 + partial_data4;

  return (float) comp_press;
}
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */
 uint8_t txt_buf_results[1024];

 HAL_StatusTypeDef ret;
 uint8_t txt_buf[50];
 uint8_t buf[50];

 //Temperature
 uint16_t temp_raw = 0;
 float temp_f = 0;
 unsigned int temp_dec = 0;
 unsigned int temp_ap = 0;

 //humidity
 uint16_t hum_raw = 0;
 unsigned int hum_d = 0;
 float hum_f = 0;
 unsigned int hum_ap = 0;

 //VOC
 float voc_f = 0;
 unsigned int voc_d = 0;
 uint8_t voc_raw = 0;

 //CO2
 float co2_f = 0;
 uint8_t co2_raw = 0;
 unsigned int co2_d = 0;
  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */
  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */
  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_USART2_UART_Init();
  MX_I2C1_Init();
  MX_ADC1_Init();
  MX_SPI1_Init();
  MX_USART1_UART_Init();
  /* USER CODE BEGIN 2 */

 get_NVM_parameters(); // get parameters from (non-volatile memory) for output compensation

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
 while (1)
 {
		/* USER CODE END WHILE */

		/* USER CODE BEGIN 3 */

	// (temperature and) pressure through BMP390
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_15, GPIO_PIN_RESET);
	HAL_SPI_Transmit(&hspi1, (uint8_t *)&WRITE_ENABLES, 2, 1000); // Enable sensing of pressure and temperature
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_15, GPIO_PIN_SET);

	HAL_Delay(50);

	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_15, GPIO_PIN_RESET);
	HAL_SPI_Transmit(&hspi1, (uint8_t *)&READ_PRESSURE_AND_TEMP, 1, 1000);
	HAL_SPI_Receive(&hspi1, (uint8_t *) read_buffer, 7, 1000);
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_15, GPIO_PIN_SET);

	int sensor_pressure = ((read_buffer[3]<<16) | (read_buffer[2]<<8) | read_buffer[1]);
	int sensor_temperature = ((read_buffer[6]<<16) | (read_buffer[5]<<8) | read_buffer[4]);

	float temperature = compensate_temperature (sensor_temperature);
	float pressure = compensate_pressure (sensor_pressure)/100;


	// lux
	HAL_ADC_Start(&hadc1);
	HAL_ADC_PollForConversion(&hadc1, 20);
	lux = HAL_ADC_GetValue(&hadc1);
	lux_f = lux/4.096;
	lux_d = (unsigned int)lux_f;

	HAL_Delay(250);

	// humidity and temperature

	// read address = 0x00
	buf[0] = 0x00;

	// send read address to sensor
	ret = HAL_I2C_Master_Transmit(&hi2c1, HIH7000_ADDR, buf, 1, HAL_MAX_DELAY);
	HAL_Delay(250);
	if ( ret != HAL_OK ) {	// When a Tx error occures
		strcpy((char*)txt_buf, "Error Tx\r\n");
		HAL_UART_Transmit(&huart2, txt_buf, strlen((char*)txt_buf), HAL_MAX_DELAY);
	}

	else {
		// Reading 4 bytes from sensor
		ret = HAL_I2C_Master_Receive(&hi2c1, HIH7000_ADDR, buf, 4, HAL_MAX_DELAY);
		HAL_Delay(250);

		if ( ret != HAL_OK ) { // When a Rx error occures
			strcpy((char*)txt_buf, "Error Rx\r\n");
			HAL_UART_Transmit(&huart2, txt_buf, strlen((char*)txt_buf), HAL_MAX_DELAY);
		}

		else {

			//info for humidity is in first 2 bytes, temperature in next 2 bytes
			hum_raw = ((uint16_t)(buf[0] & 0b00111111) << 8) | buf[1];
			temp_raw = (((uint16_t)buf[2] << 6) | (buf[3] >> 2));

			//calculating values for humidity
			hum_f = ((float)hum_raw / 16382.0) * 100.0;

			//calculating values for temperature

			temp_f = ((float)temp_raw / 16382.0) * 165.0 - 40.0;
			temp_dec = (unsigned int) temp_f;
			temp_ap = (temp_f - (float)temp_dec)*100;
		}
	}

	// VOC and CO2

	// read adress = 00001100
	buf[0] = 0x0C;

	// Tell MICSVZ89 that we want to read from the register
	ret = HAL_I2C_Master_Transmit(&hi2c1, MICSVZ89_ADDR, buf, 1, HAL_MAX_DELAY);

	HAL_Delay(250);

	if ( ret != HAL_OK ) {
		strcpy((char*)txt_buf, "Error Tx\r\n");
		HAL_UART_Transmit(&huart2, txt_buf, strlen((char*)txt_buf), HAL_MAX_DELAY);
	}
	else {
		// Read 2 bytes from the MICSVZ89 register
		ret = HAL_I2C_Master_Receive(&hi2c1, MICSVZ89_ADDR, buf, 2, HAL_MAX_DELAY);
		HAL_Delay(250);

		if ( ret != HAL_OK ) {
			strcpy((char*)txt_buf, "Error Rx\r\n");
			HAL_UART_Transmit(&huart2, txt_buf, strlen((char*)txt_buf), HAL_MAX_DELAY);
		}
		else {

			// Formulas from datasheet:
			voc_raw = buf[0];
			co2_raw = buf[1];

			voc_f = ((float)voc_raw-13)*(1000/229);
			co2_f = ((float)co2_raw-13)*(1000/229)+400;
			voc_d = (unsigned int) voc_f;
			co2_d = (unsigned int) co2_f;

		}
	}


	// Empty buffer
	// Initialize txt_buf_results to an empty string
	strcpy((char*)txt_buf_results, "");

	// Combine all the data into one formatted string
	sprintf((char*)txt_buf_results,
			"L:%u,T:%u.%02u,RH:%.2f,CO2:%u,VOC:%u, PR:%.2f",
			lux_d, temp_dec, temp_ap, hum_f, co2_d, voc_d, pressure );

	// Transmit the combined result through UART
	HAL_UART_Transmit(&huart1, txt_buf_results, strlen((char*)txt_buf_results), HAL_MAX_DELAY); // To ESP8266
	HAL_UART_Transmit(&huart2, txt_buf_results, strlen((char*)txt_buf_results), HAL_MAX_DELAY); // To PUTTY Console
	// Add a delay if needed
	HAL_Delay(500);


	 }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE2);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 16;
  RCC_OscInitStruct.PLL.PLLN = 336;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV4;
  RCC_OscInitStruct.PLL.PLLQ = 7;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief ADC1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_ADC1_Init(void)
{

  /* USER CODE BEGIN ADC1_Init 0 */

  /* USER CODE END ADC1_Init 0 */

  ADC_ChannelConfTypeDef sConfig = {0};

  /* USER CODE BEGIN ADC1_Init 1 */

  /* USER CODE END ADC1_Init 1 */

  /** Configure the global features of the ADC (Clock, Resolution, Data Alignment and number of conversion)
  */
  hadc1.Instance = ADC1;
  hadc1.Init.ClockPrescaler = ADC_CLOCK_SYNC_PCLK_DIV4;
  hadc1.Init.Resolution = ADC_RESOLUTION_12B;
  hadc1.Init.ScanConvMode = DISABLE;
  hadc1.Init.ContinuousConvMode = DISABLE;
  hadc1.Init.DiscontinuousConvMode = DISABLE;
  hadc1.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
  hadc1.Init.ExternalTrigConv = ADC_SOFTWARE_START;
  hadc1.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc1.Init.NbrOfConversion = 1;
  hadc1.Init.DMAContinuousRequests = DISABLE;
  hadc1.Init.EOCSelection = ADC_EOC_SINGLE_CONV;
  if (HAL_ADC_Init(&hadc1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time.
  */
  sConfig.Channel = ADC_CHANNEL_0;
  sConfig.Rank = 1;
  sConfig.SamplingTime = ADC_SAMPLETIME_3CYCLES;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN ADC1_Init 2 */

  /* USER CODE END ADC1_Init 2 */

}

/**
  * @brief I2C1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C1_Init(void)
{

  /* USER CODE BEGIN I2C1_Init 0 */
  /* USER CODE END I2C1_Init 0 */

  /* USER CODE BEGIN I2C1_Init 1 */
  /* USER CODE END I2C1_Init 1 */
  hi2c1.Instance = I2C1;
  hi2c1.Init.ClockSpeed = 100000;
  hi2c1.Init.DutyCycle = I2C_DUTYCYCLE_2;
  hi2c1.Init.OwnAddress1 = 0;
  hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c1.Init.OwnAddress2 = 0;
  hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C1_Init 2 */
  /* USER CODE END I2C1_Init 2 */

}

/**
  * @brief SPI1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_SPI1_Init(void)
{

  /* USER CODE BEGIN SPI1_Init 0 */

  /* USER CODE END SPI1_Init 0 */

  /* USER CODE BEGIN SPI1_Init 1 */

  /* USER CODE END SPI1_Init 1 */
  /* SPI1 parameter configuration*/
  hspi1.Instance = SPI1;
  hspi1.Init.Mode = SPI_MODE_MASTER;
  hspi1.Init.Direction = SPI_DIRECTION_2LINES;
  hspi1.Init.DataSize = SPI_DATASIZE_8BIT;
  hspi1.Init.CLKPolarity = SPI_POLARITY_LOW;
  hspi1.Init.CLKPhase = SPI_PHASE_1EDGE;
  hspi1.Init.NSS = SPI_NSS_SOFT;
  hspi1.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_128;
  hspi1.Init.FirstBit = SPI_FIRSTBIT_MSB;
  hspi1.Init.TIMode = SPI_TIMODE_DISABLE;
  hspi1.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
  hspi1.Init.CRCPolynomial = 10;
  if (HAL_SPI_Init(&hspi1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN SPI1_Init 2 */

  /* USER CODE END SPI1_Init 2 */

}

/**
  * @brief USART1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART1_UART_Init(void)
{

  /* USER CODE BEGIN USART1_Init 0 */

  /* USER CODE END USART1_Init 0 */

  /* USER CODE BEGIN USART1_Init 1 */

  /* USER CODE END USART1_Init 1 */
  huart1.Instance = USART1;
  huart1.Init.BaudRate = 115200;
  huart1.Init.WordLength = UART_WORDLENGTH_8B;
  huart1.Init.StopBits = UART_STOPBITS_1;
  huart1.Init.Parity = UART_PARITY_NONE;
  huart1.Init.Mode = UART_MODE_TX_RX;
  huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart1.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART1_Init 2 */

  /* USER CODE END USART1_Init 2 */

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */
  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */
  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */
  /* USER CODE END USART2_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
/* USER CODE BEGIN MX_GPIO_Init_1 */
/* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_15, GPIO_PIN_RESET);

  /*Configure GPIO pin : B1_Pin */
  GPIO_InitStruct.Pin = B1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(B1_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : PA15 */
  GPIO_InitStruct.Pin = GPIO_PIN_15;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

/* USER CODE BEGIN MX_GPIO_Init_2 */
/* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

